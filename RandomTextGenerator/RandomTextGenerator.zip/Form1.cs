﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomTextGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int length = Convert.ToInt32(textBox2.Text);
            string msg = "";
            Random r = new Random();
            if (checkBox1.Checked)
            {
                //숫자 온리
                for (int i = 0; i < length; i++)
                {
                    int a = r.Next(0, 10);
                    msg += a.ToString();
                }
            }
            else
            {
                //안숫자 허용
                for (int i = 0; i < length; i++)
                {
                    int a = r.Next(33, 127);
                    msg += Convert.ToChar(a);
                }
            }
            textBox1.Text = msg;
            Clipboard.SetText(msg);
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
